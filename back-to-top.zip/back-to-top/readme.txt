=== Back to top scroll ===
Contributors: ganeshpaygude
Tags: backtotop,scroll,top,link,scrolltop
Requires at least: 3.2
Tested up to: 4.4.1
Stable tag: 1.0
License: GPLv2

Add back to top button to scroll from bottom to top.

== Description ==

Add back to top button to scroll from bottom to top.

Major features in Back to top scroll  include:

* Add back to top button to scroll from bottom to top.

== Installation ==


1. Upload the plugin files to the '/wp-content/plugins/' directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the 'Plugins' screen in WordPress


== Frequently Asked Questions ==


== Screenshots ==

1.screenshot-1 


== Changelog ==

= 1.0 =
* current version 1.0 


== Upgrade Notice ==

= 1.0 =
currently no upgrades sections

== Arbitrary section ==


== A brief Markdown Example ==

